module.exports = {  
   token: "ODA0NTc1MjUxOTg3NTYyNTE2.YBOVGA.JJvWyrNOqX2fO6TJgyTttxjhq_s",
    api: "AIzaSyA9ZXHTIrtHJeQoxkUgJcyQp82pTOJfvKY",
    prefix: "d!",
    id: "804575251987562516",
    footerTxt: "No more toxic people",
    embedColor: 2067276,
    errors: {
        incorrectUsage: "For more help and a detailed description of each command, `d!help`"
    },
    footerImg: "https://image.shutterstock.com/image-vector/non-toxic-symbol-thin-line-260nw-1552944680.jpg",
  important: "[Invite link](https://discord.com/oauth2/authorize?client_id=804575251987562516&permissions=8&scope=bot)"
};