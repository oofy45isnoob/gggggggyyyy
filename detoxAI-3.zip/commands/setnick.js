const Discord = require('discord.js');

module.exports = {
name: "setnick",
usage: "!setnick @user newnick",
ownerOnly: false, 
cooldown: 1000,
botPermission: [],
authorPermission: [],
aliases: ["newnick","nickname"],
description: "Changes nickname of the mentioned user",
run: async (client, message, args) => {
let newname = args.slice(1).join(" ")
let user = message.mentions.users.first() || message.guild.users.cache.get(args[0])

if(!message.member.hasPermission("CHANGE_NICKNAME")) {
  return message.channel.send(`You don't have enough permission to change nickname`)
}
if(!user) {
  return message.channel.send(`Pls mention someone or use his id`)
}
await message.guild.member(user).setNickname(newname).catch(console.error)

const embed = new Discord.MessageEmbed()
.setTitle(`Nickname Changed 🎊`)
.setDescription(`✅ Successful changed ${user} to ${newname}}`)
.setColor(`RANDOM`)

await message.channel.send(embed);
}
}; 