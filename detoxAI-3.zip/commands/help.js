const { prefix, important, embedColor, footerImg, footerTxt } = require('../config.js');
const Discord = require('discord.js');
const { guildExist } = require('../database/firestore.js')

module.exports = {
	name: 'help',
	description: 'Includes all commands, and information on how you can use this bot.',
	aliases: ['commands', 'support'],
	usage: '[command name]',
	cooldown: 3
};

module.exports.run = async (client, message, args) => {
	if (!args.length) {
		const helpEmbed = new Discord.MessageEmbed()
			.setColor(embedColor)
			.setAuthor('NON-Toxic bot Help Page', footerImg)
			.setDescription(`Send \`${prefix}help [command name]\` to get info on a specific command.`)
			.addFields(
				{ name: '<a:utility:826827595608752138> Utility', value: '`help` `ping` `invite` `uptime` `poll` `announce`', inline: true },
				{ name: '<a:eyes:826828521435299890> Vision Tools', value: '`ocr`, `face`, `classify`', inline: true },
				{ name: '<:ai:826829284819730493> AI Mod', value: '`setup`,`analyze`, `corona`, `userinfo`,`suggest`,`translate`, `giverole`, `setnick`, `pokemon`, `github`', inline: true },
          {name: ' Animals', value: '`cat` `dog` `bird` `koala` `fox` `panda`'},
          {name: ' Fun', value: '`advice`, `coinflip`, `fact`, `joke`, `remind`, `status`, `stopwatch`, `8ball`, `giveaway`, `playstore`, `rps`, `trivia`, `hangman`, `tictactoe`'},
          { name: '<:billy:826830058207182918> Important Links', value: important },
          {name: 'bug', value: '`bug`'},
          {name: 'lock', value: '`lock`, `unlock`, `timelockdown`'}
			) 
			.setTimestamp()
			.setFooter(footerTxt, footerImg);
		try {
			message.channel.send(helpEmbed);
      if (await guildExist(message.guild.id) === false)message.channel.send('This guild has not yet setup my AI auto-mod. An administrator can use the command `d!setup`.')
		}
		catch (error) {
			message.reply('Please give me the `EMBED LINKS` permission.');
			console.error(`HLP0: ${error}`);
		}
		return;
	}
	const name = args[0].toLowerCase();
	const command = client.commands.get(name) || client.commands.find(c => c.aliases && c.aliases.includes(name));
	if (!command) { return message.reply('that\'s not a valid command! Do `d!help` for all my commands.'); }

	const alias = (command.aliases ? command.aliases.join(', ') : 'none');
	const usage = (command.usage ? `\`${prefix}${command.name} ${command.usage}\`` : `\`${prefix}${command.name}\``);

	const helpEmbed = new Discord.MessageEmbed()
		.setColor(embedColor)
		.setDescription(`**Command Name:** \`d!${command.name}\``)
		.addFields(
			{ name: 'Description', value: command.description },
			{ name: 'Aliases', value: alias, inline: true },
			{ name: 'Usage', value: usage, inline: true },
			{ name: 'Cooldown', value: `\`${command.cooldown || 3}\` seconds`, inline: true },
		)
		.setFooter(footerTxt, footerImg)
		.setTimestamp();
	try {
		message.channel.send(helpEmbed);
	}
	catch (error) {
		message.reply('Please give me the `EMBED LINKS` permission.');
		console.error(`HLP1: ${error}`);
	}
};
