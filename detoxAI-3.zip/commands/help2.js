const { Client, MessageEmbed } = require('discord.js')
const rm = require('discord.js-reaction-menu')
rm.reactions.back = '👈'
rm.reactions.next = '👉'
rm.reactions.first = ''
rm.reactions.stop = ''
rm.reactions.last = ''
module.exports = {
    name: 'help2',
    description: 'List all of my commands or info about a specific command.',
    aliases: ['commands'],
    usage: '',
    execute(message, args) {

new rm.menu({
    
    channel: message.channel,
    userID: message.author.id,
    pages: [
        new MessageEmbed()
        .setColor('ORANGE')
        .setDescription(`> **Page 1 ► This page.**
> **Page 2 ► Moderation page.**
> **Page 3 ► Image generation page.**
> **Page 4 ► Fun page.**`),
        new MessageEmbed({ title:'test2' }),
        new MessageEmbed({ title:'test3' }),
        new MessageEmbed({ title:'test4' }),
        new MessageEmbed({ title:'test5' })
    ]
    
})

      },
};