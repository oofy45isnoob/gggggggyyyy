const { embedColor, footerImg, footerTxt } = require('../config.js');
const Discord = require('discord.js');

module.exports = {
	name: 'invite',
	description: 'Invite the bot to your Discord server.',
	cooldown: 3
};

module.exports.run = async (_, message, __) => {
	try {
		const helpEmbed = new Discord.MessageEmbed()
			.setColor(embedColor)
			.setAuthor('Invite NON-toxic bot to your Discord server!', footerImg)
			.addFields(
				{ name: '<:invite:826830346443554848> Invite Me', value: '[Click Here to Invite Me](https://discord.com/oauth2/authorize?client_id=804575251987562516&permissions=8&scope=bot)', inline: true },
			)
			.setTimestamp()
			.setFooter(footerTxt, footerImg);
		message.channel.send(helpEmbed);
	}
	catch (err) {
		message.reply('Please give me the `EMBED LINKS` permission.');
		console.error(`INV0: ${err}`);
	}
};