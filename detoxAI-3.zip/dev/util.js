const devs = ['783990246576488498','750983874883878924'];
function isDev(message) {
	return devs.includes(message.author.id);
}

function isAdmin(message) {
  if (!message.member.hasPermission(`ADMINISTRATOR`, { checkAdmin: true, checkOwner: true})) {
    return false
  } else {
    return true
  }
}

module.exports = { isDev, isAdmin };